<?php

function encr($str,$key) {
	$iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length('aes-256-cbc'));
	$encrypted = openssl_encrypt($str, 'aes-256-cbc', $key, 0, $iv);
	return base64_encode($encrypted . '::' . $iv);
}

function decr($str,$key) {
	list($encrypted_data, $iv) = explode('::', base64_decode($str), 2);
	return openssl_decrypt($encrypted_data, 'aes-256-cbc', $key, 0, $iv);
}

function admin_check() {
	if($_SESSION['user']['id'] != 1) {
		header('location: logout.php');
		exit;
	}
}