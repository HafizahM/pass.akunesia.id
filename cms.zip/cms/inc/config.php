<?php
// Setting up the time zone
date_default_timezone_set('Asia/Dhaka');

// Host Name
$dbhost = 'localhost';

// Database Name
$dbname = 'epm';

// Database Username
$dbuser = 'root';

// Database Password
$dbpass = '';

// Defining base url
define("BASE_URL", "http://localhost/phpscriptpoint/epm/epm/cms/");

// Defining private key
define("PRIVATE_KEY", "E39tDBCgZ2GBUJKArGeXrbE3AVe6rL2wGJ6SPC5M");

try {
	$pdo = new PDO("mysql:host={$dbhost};dbname={$dbname}", $dbuser, $dbpass);
	$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch( PDOException $ex ) {
	echo "Connection error :" . $ex->getMessage();
}